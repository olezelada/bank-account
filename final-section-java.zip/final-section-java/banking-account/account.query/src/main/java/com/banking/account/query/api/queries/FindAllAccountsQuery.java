package com.banking.account.query.api.queries;

import com.banking.cqrs.core.queries.BaseQuery;

public class FindAllAccountsQuery extends BaseQuery {
}
