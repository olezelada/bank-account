package com.banking.account.common.dto;

public enum AccountType {
    SAVINGS, CURRENT
}
