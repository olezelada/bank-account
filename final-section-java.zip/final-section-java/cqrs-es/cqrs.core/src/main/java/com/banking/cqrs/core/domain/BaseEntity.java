package com.banking.cqrs.core.domain;

public abstract class BaseEntity {
}
