package com.banking.cqrs.core.queries;

public abstract class BaseQuery {
}
