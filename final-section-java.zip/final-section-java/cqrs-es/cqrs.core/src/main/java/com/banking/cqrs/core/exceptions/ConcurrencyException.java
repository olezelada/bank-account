package com.banking.cqrs.core.exceptions;

public class ConcurrencyException extends RuntimeException {
}
